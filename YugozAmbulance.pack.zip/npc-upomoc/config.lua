Config = {}

-- Revive Service Options
Config.ReviveCost = 2500 -- Cost for the revive service
Config.ReviveAnimation = 'CODE_HUMAN_MEDIC_TEND_TO_DEAD' -- Animation used for the revive process
Config.ReviveDuration = 10000 -- Duration (in milliseconds) for the revive process
Config.EnableDebug = true
-- NPC Options
Config.DoctorModel = 's_m_m_doctor_01' -- NPC model for the doctor
Config.NPCDrivingStyle = 1074528293 -- Driving style for NPC (e.g., fast driving ignoring traffic signals)
Config.MaxRetriesForStop = 7 -- Max retries for NPC to find a stopping spot

-- Vehicle Options
Config.RoadVehicle = 'ambulance' -- Vehicle model used for road rescues
Config.HelicopterModel = 'polmav' -- Vehicle model used for helicopter rescues
Config.VehicleSpeed = 30.0 -- Speed of the vehicle (in meters/second)
Config.VehicleSpawnDistance = {min = 500, max = 650} -- Min and max distance for vehicle spawn
Config.HelicopterSpawnDistance = {min = 800, max = 1500} -- Min and max distance for helicopter spawn
Config.HelicopterAltitude = 150.0 -- Altitude for helicopter spawn
Config.HelicopterLandingAltitude = 10.0 -- Altitude for helicopter landing
Config.DefaultHelicopterLivery = 1 -- Default livery for the helicopter

-- Safe Landing Options
Config.SafeLandingSpot = vector3(1839.67, 3672.54, 34.28) -- Fixed safe landing location
Config.DriveAwayDistance = {min = 4000, max = 5000} -- Min and max distance for NPC drive-away after rescue

-- Progress Bar Options
Config.ProgressBarUpdateInterval = 1000 -- Update interval for progress bar (in milliseconds)
Config.ProgressBarLabelCar = "Doctor Distance: " -- Label for progress bar when a car is used
Config.ProgressBarLabelHeli = "Helicopter Distance: " -- Label for progress bar when a helicopter is used

-- Debug Options
Config.DebugMode = true -- Enable/Disable debug logs

-- Notifications
Config.Messages = {
    RescueInProgress = "A rescue is already in progress!",
    NotInLastStand = "You are not in last stand!",
    ErrorLastStand = "Error: Last stand state not found!",
    Underwater = "Rescue unavailable: You are underwater!",
    DoctorArriving = "The doctor is picking you up!",
    FullyRevived = "You have been fully revived!"
}

-- Discord Webhook Options
Config.DiscordWebhook = 'YOUR_WEBHOOK' -- Discord webhook for logging

-- Function to log debug messages
local function logDebug(message)
    if Config.DebugMode then
        print("[DEBUG] " .. message)
    end
end

-- Replace all instances in your script where constants are hardcoded with these `Config` values.

-- Example:
-- Change:
-- QBCore.Functions.Notify('A rescue is already in progress!', 'error')
-- To:
-- QBCore.Functions.Notify(Config.Messages.RescueInProgress, 'error')

-- Change:
-- print("[DEBUG] NPC walking to Player. Distance Remaining: " .. walkingDistance)
-- To:
-- logDebug("NPC walking to Player. Distance Remaining: " .. walkingDistance)

-- This will ensure the script is fully configurable and debug-friendly.
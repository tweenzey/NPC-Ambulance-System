fx_version 'cerulean'
game 'gta5'

author 'tweenzey'
description 'YUGOZ Help - Custom NPC Assistance Script'
version '1.0.0'
lua54 'yes'

shared_script 'config.lua'

client_script 'Client/Client.lua'
server_script 'Server/Server.lua'

escrow_ignore {
    'config.lua',
	'client.lua'
}

dependency '/assetpacks'